# Réconciliation du HEAD et du bail — lecture seule

## HEAD

Snapshot V2 :84322df0fae9db7d5989d5ee25962b8220a66008. HEAD observé :e58278153f383376b734a3bb798a5387f6c5ef35.

Le diff contient19 chemins : documentation usine/prospection, boiteProspection.ts/repondeur.ts, leurs QA, usine-agents/usine-socle et fixture noms, nouveaux outils preneur sous scripts/modele, et migration0134. Aucun fichier CF3/CF8 directement sélectionné n'est changé par ces commits.

Contrôle des six SHA bruts de l'inventaire : constructeur-ferme-qa, commun025, fermeture-e2e, site-sorti-des-formules-verifier, tsconfig PC et next-env correspondent tous exactement. Contrôle git diff entre snapshot et HEAD sur FLAGS, les routes/fichiers de CARTE extraits de v2.carte, profil, aide, package.json, ts-loader et les quatre scripts CF : aucune modification. Diff working sur ces dépendances : uniquement tsconfig, et ses octets correspondent justement à la configuration audit PC déjà validée en V2.

**Attestation bornée : CF3 et sa preuve de mutations peuvent être rattachés au nouveau HEAD sans modification du candidat.** Son fichier fermeture, ses gardes, FLAGS et ses dépendances directes sont inchangés. Les preuves historiques utilisent la référence1620723 inchangée.

**CF8 exige un nouveau typecheck ciblé du HEAD actuel avant verdict officiel.** Deux sources TypeScript existantes dans le programme ont changé : lib/agents/acquisition/boiteProspection.ts et repondeur.ts. On ne peut présenter les840/1857 fichiers validés sur l'ancien snapshot comme un typecheck actuel. Aucun besoin démontré de rejouer toutes les mutations CF3 ou le témoin historique ; le candidat est inchangé. Cette relecture n'a lancé aucun test.

## Bail et libération canonique

Le coordinateur atteste que025-10 appartient à notre exécutant interrompu par quota, pas à une équipe extérieure. La preuve locale concorde : agent codex, début2026-10-07T06:31:55Z, SHA dd9c076f49853d0a3cafb7add4eb443a189fc229, question demandant précisément une fiche distincte pour CF3/CF8 et une correction du montage CF4. L'identifiant générique codex ne permet pas, à lui seul, d'identifier un sous-agent : l'attestation du coordinateur complète cette limite. Liste collaboration au contrôle : root completed, review_cf running, vaisseau_255 erroredquota ; aucun exécutant025-10 actif dans cette liste. Le contrôle PC de processus QA ciblés était vide.

La fiche025-10 interdit explicitement constructeur-ferme-qa : cette révision doit donc rester une fiche distincte, même si la prochaine routine canonique n'estime pas leurs périmètres en chevauchement.

Option recommandée au coordinateur : sauvegarder la fiche, le lock, avant.txt et question/reponse éventuelle en OPS avec SHA, puis depuis la racine principale exécuter `node scripts/orchestre.mjs liberer 025-10`. Lecture du code deplacer : déplacement de la fiche en file, suppression lock/avant/question/reponse, régénération digest. Ne pas supprimer le lock manuellement et ne pas laisser supprimer une question utile sans sauvegarde.

Après libération : créer/valider la fiche distincte, prendre son bail canonique, appliquer uniquement le candidat SHA4980a79acd429ea88e83da26e27fbe1149ce12f9a07ad61f554599281e2b8b65 avec sauvegarde du juge base, et réaliser le typecheck courant requis. Les imports du candidat sont uniquement modules Node, typescript installé et ./fixtures/025/commun.mjs ; aucun import OPS absolu. Le dossier témoin historique utilise middleware.ts de la référence lorsqu'elle ne contient pas proxy.ts.

Aucune modification principale, libération, création de fiche, test ni commit effectués par cette relecture. Les exigences de jugement/revue restent applicables ; ce document prépare une décision concrète, pas un contournement.
