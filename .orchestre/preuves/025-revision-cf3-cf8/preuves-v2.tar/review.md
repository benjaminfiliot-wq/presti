# Relecture indépendante V2 — 07/10/2026

Verdict : **GO pour application bornée de ce candidat**, sous contrôle des SHA et sauvegarde des modifications PC. Ce verdict n'est ni le PASS officiel de 025-10, ni un résultat de déploiement, ni la clôture du chantier. Le NO-GO V1 reste conservé.

## Collecte et identité

Lecture seule des sources, du runner et des preuves ; aucun juge édité, aucun test relancé, aucune API payante ni push. Recherche Oracle : aucun processus cf-v2/constructeur-ferme-qa actif au moment du contrôle. Le résultat du dernier test strict historique est déjà dans le journal final : aucun besoin de relancer la session annoncée.

Le fichier PC logs.txt était un journal ancien arrêté sur deux erreurs CF3. Le journal actuel Oracle a été récupéré séparément dans logs-oracle-collected.txt, sans écraser l'échec ancien. Il contient le marqueur final RESULTAT V2 et aucun BLOCAGE final.

SHA256 du candidat PC, de la candidate Oracle et de scripts/cf-v2.mjs réellement exécuté : 4980a79acd429ea88e83da26e27fbe1149ce12f9a07ad61f554599281e2b8b65. Inventaire Oracle : c16edb836524cba3f536535763b7881a5bae4bdadd04a9b1462903d4796679fc.

## Corrections du NO-GO V1 vérifiées

CF3 ne repose plus seulement sur un SHA : cf3Semantique impose les protections nommées, la carte exacte et unique, présence des drapeaux dans FLAGS, existence des fichiers, defautsLigne026 historique et lectures actif(drapeau). Le contrôle constructeur appelle cf2. Le SHA LF de fermeture demeure une barrière supplémentaire fermée.

Les quatre sabotages CF3 ont une cause vérifiée directement par cf3Semantique, avant invocation du juge : protection GET supprimée ; 404 accepté avec pilotage levé ; garde pilotage supprimée dans route.ts avec fermeture intacte ; pilotage supprimé de FLAGS avec fermeture intacte. Les deux derniers sont rejetés sans erreur de SHA. Ceci répond à la régression identifiée dans V1.

CF8 admet deux JSON exacts uniquement : config Next16 de base, ou cette même config avec les deux includes audit PC. Aucun changement de compilerOptions/exclude n'est accepté. Le vrai typecheck, les quatre sources requises, lib.es5, le script typecheck historique et les interdictions d'annotations restent exigés. Les programmes des deux configs ont été comparés : code0, listes identiques de 1857 fichiers ; le juge courant compte840 fichiers dans la racine. Les dossiers audit étaient absents à la capture ; cette preuve n'atteste pas le contenu de futurs fichiers générés, qui restera soumis au typecheck.

Le mode --temoin utilise désormais cf3Historique/cf8Historique seulement après construireTemoin et extraireReference, par une autorisation en mémoire de la racine construite ; aucun simple nom de chemin ou fichier de marque ne sélectionne ce mode. La référence authentifiée est1620723f6637a02545a979e8ab38f667b3d53392. PASS CF3/CF8 historique :325 sources ; suppression carte constructeur et strict=false historiques refusées.

## Limites et garde d'application

Les contrôles de garde restent textuels, comme leur contrat précédent : présence actif(drapeau) ne démontre pas à elle seule l'ordre d'exécution de toutes les routes ni leur authentification en production. Le contrôle 404 est une exécution simulée des expressions du juge sur une route pilotage, pas un E2E réseau. Les sabotages et le SHA établissent la non-régression bornée du candidat, sans remplacer les autres juges de sécurité.

Avant application : confirmer que le juge principal correspond toujours à sa sauvegarde/inventaire, conserver tsconfig PC, installer uniquement ce fichier candidat, vérifier les critères officiels avec bail unique et conserver leurs verdicts. Tout changement du candidat ou du snapshot de fermeture demande nouvelle relecture. Les en-têtes de contrat historiques devraient être complétés pour expliquer les modes courant/historique et la liste fermée actuelle ; ce point documentaire ne justifie pas d'assouplissement des contrôles.

Le journal final prouve la copie Oracle uniquement. Aucun PASS officiel ni déploiement n'a été effectué par cette relecture.
